"use strict";
cc._RF.push(module, 'ca133dybNFKbIwU5nZEOq0Y', 'Enemy');
// Script/Enemy.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    moveSpeed: 10,
    // Tốc độ di chuyển của quái vật
    moveDistance: 200
  },
  update: function update(dt) {
    // Di chuyển quái vật theo hướng xuống
    var deltaMove = cc.v2(0, -this.moveSpeed * dt);
    this.node.position = this.node.position.add(deltaMove);
  },
  onCollisionEnter: function onCollisionEnter(other, self) {
    if (other.node.name === 'bullet5') {
      console.log("va cham dan");
      other.node.destroy(); // Hủy đối tượng đạn

      this.node.destroy(); // Hủy đối tượng quái vật
    }

    if (other.node.name === 'player') {
      console.log("va cham may bay");
    }
  } // onCollisionEnter: function (other, self) {
  //     if (other.node.name === 'bullet5') {
  //         console.log("va cham dan");
  //         other.node.destroy(); // Hủy đối tượng đạn
  //         this.node.destroy(); // Hủy đối tượng quái vật
  //     }
  //     if (other.node.name === 'player') {
  //         console.log("va cham may bay");
  //     }
  // }

});

cc._RF.pop();