"use strict";
cc._RF.push(module, '799204JDmFM/r9NHq1ZwYrd', 'Canvas');
// Script/Canvas.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    bonhangdoPrefab: {
      "default": null,
      type: cc.Prefab
    },
    bonhangxanhPrefab: {
      "default": null,
      type: cc.Prefab
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.spawnEnemies(this.bonhangdoPrefab, 100);
    this.spawnEnemies(this.bonhangxanhPrefab, 200);
  },
  start: function start() {},
  spawnEnemies: function spawnEnemies(ob, y) {
    var numEnemies = 6; // Số lượng quái vật

    var enemySize = ob.data.getContentSize(); // Kích thước của mỗi con quái vật

    var spacing = 50; // Khoảng cách giữa các con quái vật

    var canvas = cc.Canvas.instance.node; // Lấy đối tượng Canvas

    var canvasSize = canvas.getContentSize(); // Kích thước của Canvas

    var totalWidth = (enemySize.width + spacing) * numEnemies - spacing; // Tổng chiều rộng của hàng các quái vật

    var startX = -totalWidth / 2; // Vị trí bắt đầu của hàng

    var moveDirection = 1; // Hướng di chuyển ban đầu (1: từ trái qua phải, -1: từ phải qua trái)

    var currentX = startX; // Vị trí hiện tại của hàng

    for (var i = 0; i < numEnemies; i++) {
      var enemy = cc.instantiate(ob);
      enemy.position = cc.v2(currentX, y); // Đặt vị trí của quái vật trên hàng

      canvas.addChild(enemy); // Thêm quái vật vào Canvas

      currentX += (enemySize.width + spacing) * moveDirection; // Cập nhật vị trí của hàng theo hướng di chuyển
      // Kiểm tra nếu hàng vượt qua biên trái hoặc phải của Canvas, thay đổi hướng di chuyển

      if (currentX < startX || currentX > startX + totalWidth) {
        moveDirection *= -1;
      }
    }
  }
});

cc._RF.pop();