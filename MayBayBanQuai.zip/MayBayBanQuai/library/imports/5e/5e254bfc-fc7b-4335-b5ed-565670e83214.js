"use strict";
cc._RF.push(module, '5e254v8/HtDNbXtVlZw6DIU', 'animation');
// Script/animation.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    animationClip: {
      "default": null,
      type: cc.AnimationClip
    }
  },
  onLoad: function onLoad() {
    // Lấy Component Animation
    var animationComponent = this.getComponent(cc.Animation); // Thêm Animation Clip vào Component Animation

    animationComponent.addClip(this.animationClip); // Chạy Animation Clip với tên của nó

    animationComponent.play('saobien_animation');
  }
});

cc._RF.pop();