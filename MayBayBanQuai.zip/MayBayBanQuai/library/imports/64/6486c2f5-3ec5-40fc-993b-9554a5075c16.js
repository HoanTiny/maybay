"use strict";
cc._RF.push(module, '6486cL1PsVA/Jk7lVSlB1wW', 'Bullet');
// Script/Bullet.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
// cc.Class({
//     extends: cc.Component,
//     properties: {
//         bulletSpeed: 500
//     },
//     onLoad() {
//         // Khởi tạo sự di chuyển của viên đạn
//         this.velocity = cc.v2(0, this.bulletSpeed);
//         console.log(this.velocity);
//     },
//     update(dt) {
//         // Di chuyển viên đạn dựa trên tốc độ
//         const deltaMove = this.velocity.mul(dt);
//         this.node.position = this.node.position.add(deltaMove);
//     },
//     move(velocity) {
//         // Thiết lập tốc độ di chuyển của viên đạn
//         this.velocity = velocity;
//     }
// });
cc.Class({
  "extends": cc.Component,
  properties: {
    bulletSpeed: 500
  },
  onLoad: function onLoad() {
    this.velocity = cc.v2(0, this.bulletSpeed); // console.log(this.velocity);
  },
  update: function update(dt) {
    var deltaMove = this.velocity.mul(dt);
    this.node.position = this.node.position.add(deltaMove);
    this.node.y += 50;
  }
});

cc._RF.pop();