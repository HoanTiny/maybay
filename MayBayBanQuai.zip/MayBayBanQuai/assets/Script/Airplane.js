// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

// cc.Class({
//     extends: cc.Component,

//     properties: {
//         // foo: {
//         //     // ATTRIBUTES:
//         //     default: null,        // The default value will be used only when the component attaching
//         //                           // to a node for the first time
//         //     type: cc.SpriteFrame, // optional, default is typeof default
//         //     serializable: true,   // optional, default is true
//         // },
//         // bar: {
//         //     get () {
//         //         return this._bar;
//         //     },
//         //     set (value) {
//         //         this._bar = value;
//         //     }
//         // },
//     },

//     // LIFE-CYCLE CALLBACKS:

//     // onLoad () {},

//     start () {

//     },

//     // update (dt) {},
// });

// cc.Class({
//     extends: cc.Component,

//     properties: {
//         bulletPrefab: {  // Prefab của viên đạn
//             default: null,
//             type: cc.Prefab
//         },
//         enemyPrefab: {  // // Prefab của quái vật
//             default: null,
//             type: cc.Prefab
//         },
//         bulletSpeed: 500,  // Tốc độ di chuyển của viên đạn
//         bulletInterval: 0.001,  // Khoảng thời gian giữa các lần bắn viên đạn
//         canShoot: true  // Biến kiểm tra xem có thể bắn viên đạn hay không
//     },

//     onLoad() {
//         // Gắn sự kiện "touchstart" và "touchmove"
//         this.node.on('touchstart', this.onStartTouch, this);
//         this.node.on('touchmove', this.onMoveTouch, this);

//     },

//     onStartTouch(event) {
//         // Lưu vị trí bắt đầu của chạm vào
//         this.touchStartPos = event.getLocation();
//     },

//     onMoveTouch(event) {
//         // Tính toán và cập nhật vị trí di chuyển của chạm
//         const touchPos = event.getLocation();
//         const dx = touchPos.x - this.touchStartPos.x;
//         const dy = touchPos.y - this.touchStartPos.y;

//         const newPos = this.node.position.add(cc.v2(dx, dy));
//         this.node.position = newPos;

//         this.touchStartPos = touchPos;

//         if (this.canShoot) {
//             // Nếu có thể bắn viên đạn, lên lịch gọi phương thức shootBullet
//             this.schedule(this.shootBullet, this.bulletInterval);
//             this.canShoot = false;
//         }
//     },
    

//     shootBullet() {

//         if (this.bulletPrefab) {

//             // Tạo viên đạn từ Prefab
//             const bullet = cc.instantiate(this.bulletPrefab);
//             bullet.position = this.node.position;  // Đặt vị trí bắn viên đạn tại vị trí hiện tại của máy bay
//             this.node.parent.addChild(bullet);  // Thêm viên đạn vào parent của máy bay

//             const bulletVelocity = cc.v2(0, this.bulletSpeed);  // Vector tốc độ di chuyển của viên đạn

//             const bulletBody = bullet.getComponent(cc.RigidBody);  // Lấy component RigidBody của viên đạn
//             console.log(bulletBody)

//             if (bulletBody) {               
//                 bulletBody.linearVelocity = bulletVelocity;  // Đặt tốc độ di chuyển của viên đạn
//                 console.log(bulletVelocity)
//             }
//         }
//     }
// });



cc.Class({
    extends: cc.Component,

    properties: {
        bulletPrefab: {  // Prefab của viên đạn
            default: null,
            type: cc.Prefab
        },
        // bonhangdoPrefab: {
        //     default: null,
        //     type: cc.Prefab
        // },
        bulletSpeed: 500,  // Tốc độ của viên đạn
        bulletInterval: 0.1,  // Thời gian giữa các lần bắn đạn
        canShoot: true,// Biến kiểm tra xem có thể bắn đạn hay không
    },

    onLoad() {
        // Gắn sự kiện "touchstart" và "touchmove"
        this.node.on('touchstart', this.onStartTouch, this);
        this.node.on('touchmove', this.onMoveTouch, this);

        var manager = cc.director.getCollisionManager();
        manager.enabled = true;

        // Gọi hàm để tạo quái vật khi bắt đầu
        // this.spawnEnemies();
    },

    onStartTouch(event) {
        // Lưu vị trí bắt đầu của chạm
        this.touchStartPos = event.getLocation();
    },

    onMoveTouch(event) {
        // Tính toán và cập nhật vị trí di chuyển của chạm
        const touchPos = event.getLocation();
        const dx = touchPos.x - this.touchStartPos.x;
        const dy = touchPos.y - this.touchStartPos.y;

        const newPos = this.node.position.add(cc.v2(dx, dy));
        this.node.position = newPos;

        this.touchStartPos = touchPos;

        if (this.canShoot) {
            // Nếu có thể bắn đạn, lên lịch gọi phương thức shootBullet
            this.schedule(this.shootBullet, this.bulletInterval);
            this.canShoot = false;
        }
    },

    shootBullet() {
        if (this.bulletPrefab) {
            // Tạo viên đạn từ Prefab
            const bullet = cc.instantiate(this.bulletPrefab);
            bullet.position = this.node.position;  // Đặt vị trí bắn viên đạn tại vị trí hiện tại của máy bay
            this.node.parent.addChild(bullet);  // Thêm viên đạn vào parent của máy bay

            const bulletVelocity = cc.v2(0, this.bulletSpeed);  // Vector tốc độ di chuyển của viên đạn

            // TODO: Xử lý va chạm giữa đạn và quái vật

        }
    },

    
    

       
});











